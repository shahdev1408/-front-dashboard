(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_recharts_es6_e825418c._.js",
  "static/chunks/node_modules_48601542._.js",
  "static/chunks/app_cce1e589._.js"
],
    source: "dynamic"
});
