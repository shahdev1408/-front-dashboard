__turbopack_load_page_chunks__("/_error", [
  "static/chunks/22121_next_dist_compiled_0e8594fe._.js",
  "static/chunks/22121_next_dist_shared_lib_780ee813._.js",
  "static/chunks/22121_next_dist_client_138b68b2._.js",
  "static/chunks/22121_next_dist_8297c982._.js",
  "static/chunks/22121_next_error_4f7e8b59.js",
  "static/chunks/[next]_entry_page-loader_ts_97493523._.js",
  "static/chunks/22121_react-dom_93e23e4a._.js",
  "static/chunks/22121_bc2e99ee._.js",
  "static/chunks/[root-of-the-server]__118204b4._.js",
  "static/chunks/sme_dashboard_frontend5_1_pages__error_2da965e7._.js",
  "static/chunks/turbopack-sme_dashboard_frontend5_1_pages__error_3e633deb._.js"
])
