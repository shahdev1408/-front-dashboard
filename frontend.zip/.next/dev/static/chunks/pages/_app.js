__turbopack_load_page_chunks__("/_app", [
  "static/chunks/22121_next_dist_compiled_0e8594fe._.js",
  "static/chunks/22121_next_dist_shared_lib_40221283._.js",
  "static/chunks/22121_next_dist_client_138b68b2._.js",
  "static/chunks/22121_next_dist_23cf2261._.js",
  "static/chunks/22121_next_app_f7939c61.js",
  "static/chunks/[next]_entry_page-loader_ts_7f9434bd._.js",
  "static/chunks/22121_react-dom_93e23e4a._.js",
  "static/chunks/22121_bc2e99ee._.js",
  "static/chunks/[root-of-the-server]__4c3696bf._.js",
  "static/chunks/sme_dashboard_frontend5_1_pages__app_2da965e7._.js",
  "static/chunks/turbopack-sme_dashboard_frontend5_1_pages__app_dd23a1d3._.js"
])
