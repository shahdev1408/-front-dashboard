globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/22121_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_9540e0cf._.js",
    "static/chunks/22121_next_dist_compiled_react-dom_9ed88a5a._.js",
    "static/chunks/22121_next_dist_compiled_react-server-dom-turbopack_477d1832._.js",
    "static/chunks/22121_next_dist_compiled_next-devtools_index_1b8495b4.js",
    "static/chunks/22121_next_dist_compiled_8bb44e12._.js",
    "static/chunks/22121_next_dist_client_9a055bb7._.js",
    "static/chunks/22121_next_dist_b53cc747._.js",
    "static/chunks/22121_@swc_helpers_cjs_1b19c1b5._.js",
    "static/chunks/sme_dashboard_frontend5_1_a0ff3932._.js",
    "static/chunks/turbopack-sme_dashboard_frontend5_1_e9064822._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];