var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_app.js")
R.c("server/chunks/ssr/[root-of-the-server]__00d1d95c._.js")
R.m("[project]/sme_dashboard/frontend5.1/node_modules/next/app.js [ssr] (ecmascript)")
module.exports=R.m("[project]/sme_dashboard/frontend5.1/node_modules/next/app.js [ssr] (ecmascript)").exports
