module.exports = [
"[project]/sme_dashboard/frontend5.1/.next-internal/server/app/smes/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=sme_dashboard_frontend5_1__next-internal_server_app_smes_page_actions_3c6222ff.js.map