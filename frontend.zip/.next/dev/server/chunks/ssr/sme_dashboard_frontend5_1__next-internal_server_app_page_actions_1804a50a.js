module.exports = [
"[project]/sme_dashboard/frontend5.1/.next-internal/server/app/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=sme_dashboard_frontend5_1__next-internal_server_app_page_actions_1804a50a.js.map