module.exports = [
"[project]/sme_dashboard/frontend5.1/.next-internal/server/app/_not-found/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=9cb85_frontend5_1__next-internal_server_app__not-found_page_actions_d66b7362.js.map