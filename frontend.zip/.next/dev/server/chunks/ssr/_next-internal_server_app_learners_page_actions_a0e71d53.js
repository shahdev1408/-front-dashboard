module.exports = [
"[project]/.next-internal/server/app/learners/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_learners_page_actions_a0e71d53.js.map