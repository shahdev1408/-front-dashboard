module.exports = [
"[project]/sme_dashboard/frontend5.1/.next-internal/server/app/courses/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=7f461_dashboard_frontend5_1__next-internal_server_app_courses_page_actions_168ddf31.js.map