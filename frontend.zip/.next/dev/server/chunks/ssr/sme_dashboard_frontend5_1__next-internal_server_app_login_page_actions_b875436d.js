module.exports = [
"[project]/sme_dashboard/frontend5.1/.next-internal/server/app/login/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=sme_dashboard_frontend5_1__next-internal_server_app_login_page_actions_b875436d.js.map